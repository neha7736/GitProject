INSERT into beer(name,abv) VALUES('Neha R' , 7.5);
INSERT into beer(name,abv) VALUES('ABC' , 5.5);
INSERT into beer(name,abv) VALUES('DEF' , 6.5);

COMMIT;
